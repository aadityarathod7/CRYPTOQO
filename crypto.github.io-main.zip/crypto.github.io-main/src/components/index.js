export { default as Navbar} from './Navbar';
export { default as Cryptocurrencies} from './Cryptocurrencies';
export { default as Homepage} from './Homepage';
export { default as Wishlist} from './Wishlist';
export { default as News} from './News';
export { default as CryptoDetails} from './CryptoDetails';